const StarButton = () => (
  <div className="star-button-container">
    <p>
    </p>

  </div>
);

export default StarButton;
